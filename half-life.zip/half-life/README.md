# half life

A Pen created on CodePen.io. Original URL: [https://codepen.io/Dmitry-Shanin/pen/YPKvpdd](https://codepen.io/Dmitry-Shanin/pen/YPKvpdd).

